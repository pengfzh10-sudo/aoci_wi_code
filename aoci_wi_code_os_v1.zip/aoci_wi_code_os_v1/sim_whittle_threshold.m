function sim_whittle_threshold()
%% ---------------------------------------------------------------------
%% ----------------Whittle Index and Optimal Threshold Simulation-------
%% ---------------------------------------------------------------------

%% -----------------For Figure 4-------------------------------------
%% Parameter Definitions
    pr =  3/4 ;
    C  =  40;
    delta = (0:0.1:30)';
    num_G = 100000;
    mu = 1;
    L = 1;
    %% Generate Channel Delays
    [G, Y] = generate_channel_delay(num_G, pr, 'exp',mu,L);
    
    
    
    %% Calculating Whittle Index and Optimal Threshold
    wi_aoci = whittle_index_aoci(delta,C,G,Y);
    optimal_threshold = threhold_aoci(C,G,Y);
    
    %% Plot the result
    figure
    hold on, grid on, box on
    xticks(0:5:30);
    yticks(-50:25:100);
    plot(delta,wi_aoci,'r-',optimal_threshold,0,'kv','markersize',10,'linewidth',2)
    legend('Whittle index of AoCI','Threshold of AoCI','Location','Best');
    xlabel('$\delta$','Interpreter', 'Latex')
    ylabel('$W(\delta)$','Interpreter', 'Latex')
    set(gca,'FontSize',14)

end
This code is for the simulation of goal-oriented status updating communication.

sim_top.m : the main function
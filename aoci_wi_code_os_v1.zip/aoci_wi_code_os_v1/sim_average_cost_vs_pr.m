function sim_average_cost_vs_pr(resolution,total_time,num_sample_path,num_G)
%% ----------------------------------------------------------------------
%% ----------------Offline Simulation------------------------------------
%% ----------Simulations about Average cost versus pr---------------------
%% ----------------------------------------------------------------------


%% Common Parameters, Channel and Policy Definition
channel = ['exp', 'const', 'nomal', 'logn', 'bursty', 'correlate'];
policy = ['aoci_whittle','aoi_whittle','maf_zw','macf_zw'];
if(nargin ~= 4)
    resolution = 0.05 ;
    total_time = 3000 ;
    num_sample_path = 1 ;
    num_G = 5000;
end
rand_seed = 100 ;
rng(rand_seed);

pr_set = 0:0.1:0.95 ;
C = 10;
lambda  = 1;

var_x = pr_set;
avg_cost_aoci_wi1    = zeros(1,length(var_x));
avg_cost_aoi_wi1     = zeros(1,length(var_x));
avg_cost_maf_zw1     = zeros(1,length(var_x));
avg_cost_macf_zw1    = zeros(1,length(var_x));
avg_cost_aoci_wi2    = zeros(1,length(var_x));
avg_cost_aoi_wi2     = zeros(1,length(var_x));
avg_cost_maf_zw2     = zeros(1,length(var_x));
avg_cost_macf_zw2    = zeros(1,length(var_x));

%% Evaluation of Policies
parfor ii = 1:length(var_x)
    ii
    pr = var_x(ii);
    N = 4;
    L = 2;
    avg_cost_aoci_wi1(ii) = offline_policy_evaluation('aoci_whittle',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_aoi_wi1(ii) = offline_policy_evaluation('aoi_whittle',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_maf_zw1(ii) = offline_policy_evaluation('maf_zw',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_macf_zw1(ii) = offline_policy_evaluation('macf_zw',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
    N = 1;
    L = 1;
    avg_cost_aoci_wi2(ii) = offline_policy_evaluation('aoci_whittle',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_aoi_wi2(ii) = offline_policy_evaluation('aoi_whittle',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_maf_zw2(ii) = offline_policy_evaluation('maf_zw',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_macf_zw2(ii) = offline_policy_evaluation('macf_zw',num_sample_path, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
end

%% Plot Result
figure
set(gcf, 'Position', [100, 100, 500, 500]);
pbaspect([1 1 1])
hold on, grid on, box on

xticks(0:0.2:1);
yticks(0:30:150);
ylim([0 150]);
plot(var_x,avg_cost_aoci_wi1,'r-',...
     var_x,avg_cost_aoi_wi1,'b-.',...
     var_x,avg_cost_maf_zw1,'k--',...
     var_x,avg_cost_macf_zw1,'g:',...
     'linewidth',2)
%legend('AoCI, N=4, L=2','AoI, N=4, L=2','MAF-ZW, N=4, L=2','MACF-ZW, N=4, L=2',...
       %'AoCI, N=1, L=1','AoI, N=1, L=1','MAF-ZW, N=1, L=1','MACF-ZW, N=1, L=1','Location','Best','FontSize', 10)
legend('AoCI','AoI','MAF-ZW','MACF-ZW','Location','Best','FontSize', 18)
xlabel('$p_r$','Interpreter', 'Latex','FontSize',18)
ylabel('Average Cost','Interpreter', 'Latex','FontSize',18)
set(gca,'FontSize',18)

figure
set(gcf, 'Position', [100, 100, 500, 500]);
pbaspect([1 1 1])
hold on, grid on, box on
xticks(0:0.2:1);
yticks(0:10:40);
ylim([0 40]);
plot(var_x,avg_cost_aoci_wi2,'r-',...
     var_x,avg_cost_aoi_wi2,'b-.',...
     var_x,avg_cost_maf_zw2,'k--',...
     var_x,avg_cost_macf_zw2,'g:',...
     'linewidth',2)
legend('AoCI','AoI','MAF-ZW','MACF-ZW','Location','Best','FontSize', 18)
xlabel('$p_r$','Interpreter', 'Latex','FontSize',18)
ylabel('Average Cost','Interpreter', 'Latex','FontSize',18)
set(gca,'FontSize',18)



end
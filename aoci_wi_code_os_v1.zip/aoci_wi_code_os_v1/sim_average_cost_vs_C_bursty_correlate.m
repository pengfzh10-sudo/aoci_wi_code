function sim_average_cost_vs_C_bursty_correlate(resolution,total_time,num_sample_path,num_G)
%% ----------------------------------------------------------------------
%% ----------------Offline Simulation------------------------------------
%% ----------Simulations about Average cost versus lambda---------------------
%% ----------------------------------------------------------------------


%% Common Parameters, Channel and Policy Definition
channel = ['exp', 'const', 'nomal', 'logn', 'bursty', 'correlate'];
policy = ['aoci_whittle','aoi_whittle','maf_zw','macf_zw'];
if(nargin ~= 4)
    resolution = 0.05 ;
    total_time = 3000 ;
    num_sample_path = 1 ;
    num_G = 5000;
end
rand_seed = 100 ;
rng(rand_seed);
N = 4;
L = 2;
pr = 1/4 ;
lambda = 1;
C_set = 0:5:40;

var_x = C_set;
avg_cost_aoci_wi_bursty    = zeros(1,length(var_x));
avg_cost_aoi_wi_bursty     = zeros(1,length(var_x));
avg_cost_maf_zw_bursty     = zeros(1,length(var_x));
avg_cost_macf_zw_bursty    = zeros(1,length(var_x));
avg_cost_aoci_wi_correlate    = zeros(1,length(var_x));
avg_cost_aoi_wi_correlate     = zeros(1,length(var_x));
avg_cost_maf_zw_correlate     = zeros(1,length(var_x));
avg_cost_macf_zw_correlate    = zeros(1,length(var_x));

%% Evaluation of Policies
parfor ii = 1:length(var_x)
    ii
    C = C_set(ii);
    avg_cost_aoci_wi_bursty(ii) = offline_policy_evaluation('aoci_whittle',num_sample_path, 'bursty',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_aoi_wi_bursty(ii) = offline_policy_evaluation('aoi_whittle',num_sample_path, 'bursty',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_maf_zw_bursty(ii) = offline_policy_evaluation('maf_zw',num_sample_path, 'bursty',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_macf_zw_bursty(ii) = offline_policy_evaluation('macf_zw',num_sample_path, 'bursty',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_aoci_wi_correlate(ii) = offline_policy_evaluation('aoci_whittle',num_sample_path, 'correlate',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_aoi_wi_correlate(ii) = offline_policy_evaluation('aoi_whittle',num_sample_path, 'correlate',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_maf_zw_correlate(ii) = offline_policy_evaluation('maf_zw',num_sample_path, 'correlate',num_G,lambda,N,L,pr,C,resolution,total_time);
    avg_cost_macf_zw_correlate(ii) = offline_policy_evaluation('macf_zw',num_sample_path, 'correlate',num_G,lambda,N,L,pr,C,resolution,total_time);
end

%% Plot Result
% figure
% hold on, grid on, box on
% xticks(0:5:40);
% yticks(0:25:200);
% plot(var_x,avg_cost_aoci_wi_bursty,'r-+',...
%     var_x,avg_cost_aoi_wi_bursty,'b-.+',...
%     var_x,avg_cost_maf_zw_bursty,'k--+',...
%     var_x,avg_cost_macf_zw_bursty,'g:+',...
%     var_x,avg_cost_aoci_wi_correlate,'r-',...
%     var_x,avg_cost_aoi_wi_correlate,'b-.',...
%     var_x,avg_cost_maf_zw_correlate,'k--',...
%     var_x,avg_cost_macf_zw_correlate,'g:',...
%     'linewidth',2)
% legend('AoCI, bursty','AoI, bursty','MAF-ZW, bursty','MACF-ZW, bursty',...
%        'AoCI, correlate','AoI, correlate','MAF-ZW, correlate','MACF-ZW, correlate','Location','Best','FontSize', 10)
% xlabel('$C$','Interpreter', 'Latex')
% ylabel('Average Cost','Interpreter', 'Latex')
% set(gca,'FontSize',14)

figure
set(gcf, 'Position', [100, 100, 500, 500]);
    pbaspect([1 1 1])
    hold on, grid on, box on
    xticks(0:10:40);
    yticks(0:25:180);
    ylim([50 150]);
    plot(var_x,avg_cost_aoci_wi_bursty,'r-',...
         var_x,avg_cost_aoi_wi_bursty,'b-.',...
         var_x,avg_cost_maf_zw_bursty,'k--',...
         var_x,avg_cost_macf_zw_bursty,'g:',...
         'linewidth',2)
    %legend('AoCI, N=4, L=2','AoI, N=4, L=2','MAF-ZW, N=4, L=2','MACF-ZW, N=4, L=2',...
           %'AoCI, N=1, L=1','AoI, N=1, L=1','MAF-ZW, N=1, L=1','MACF-ZW, N=1, L=1','Location','Best','FontSize', 10)
    legend('AoCI','AoI','MAF-ZW','MACF-ZW','Location','Best','FontSize', 18)
    xlabel('$C$','Interpreter', 'Latex','FontSize',18)
    ylabel('Average Cost','Interpreter', 'Latex','FontSize',18)
    set(gca,'FontSize',18)
    
    figure
    set(gcf, 'Position', [100, 100, 500, 500]);
    pbaspect([1 1 1])
    hold on, grid on, box on
    xticks(0:10:40);
    yticks(0:25:200);
    ylim([75 175]);
    plot(var_x,avg_cost_aoci_wi_correlate,'r-',...
         var_x,avg_cost_aoi_wi_correlate,'b-.',...
         var_x,avg_cost_maf_zw_correlate,'k--',...
         var_x,avg_cost_macf_zw_correlate,'g:',...
         'linewidth',2)
    legend('AoCI','AoI','MAF-ZW','MACF-ZW','Location','Best','FontSize', 18)
    xlabel('$C$','Interpreter', 'Latex','FontSize',18)
    ylabel('Average Cost','Interpreter', 'Latex','FontSize',18)
    set(gca,'FontSize',18)




end

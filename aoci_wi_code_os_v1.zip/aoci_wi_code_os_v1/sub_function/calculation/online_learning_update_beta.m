function [beta_update ] = online_learning_update_beta(beta,reward,time,k,Y_avg,beta_min,beta_max)
    beta_update =   beta + 1/(k+2)/Y_avg *(reward-beta*time);
    beta_update = min(beta_max,max(beta_min,beta_update));
end
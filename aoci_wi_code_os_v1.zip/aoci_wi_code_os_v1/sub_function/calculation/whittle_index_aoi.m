function [wi] = whittle_index_aoi(delta,C,G,Y)
    
    row = size(delta,1);
    wi = zeros(row,1);
    for ii = 1:row
        wi(ii,1) = 1 / mean(Y) * ((delta(ii,1) + mean(Y)) * mean(max(delta(ii,1),Y)) ...
            - ( 1 / 2 * mean(max(delta(ii,1).^2,Y.^2)) + mean(max(delta(ii,1),Y)) * mean(Y)) ) - C;
    
    end

    
end
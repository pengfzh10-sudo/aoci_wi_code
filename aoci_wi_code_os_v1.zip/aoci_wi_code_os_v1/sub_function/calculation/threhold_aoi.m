function [beta ] = threhold_aoi(C,G,Y)

   % beta = ( sqrt(pr+2*omega*C*(1-pr))-pr ) / (1-pr);
    right_beta = 100;
    left_beta = 0;
    threshold = 0.001; 
    ite = 1000;
    ii = 0;
    while(ii <= ite)
       m =  (left_beta + right_beta)/2; 
       if (expression_aoi(m,C,G,Y) * expression_aoi(left_beta,C,G,Y) < 0)
          right_beta = m;
       else 
           left_beta = m;
       end
       if((right_beta - left_beta) /2 < threshold)
           beta = right_beta;
           break;
       end
       ii = ii + 1;
    end

end
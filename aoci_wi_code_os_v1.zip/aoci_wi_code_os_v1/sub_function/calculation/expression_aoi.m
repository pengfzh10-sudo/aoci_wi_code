function y = expression_aoi(beta,C,G,Y)
    y = sum(max(beta.^2,Y.^2))/length(Y)+2*C*mean(Y)...
        - beta* 2*sum(max(beta,Y))/length(Y);

end
function y = expression_aoci(beta,C,G,Y)
    y = sum(G.^2 + (max(beta -Y,0)).^2 + 2 * Y .* max(beta -Y,0) + 2* (C-mean(G)+mean(Y)) * G)/length(G)...
        - beta* 2*sum(G+max(beta -Y,0))/length(G);
%     
%     y = sum(G.^2 + (beta -Y).^2 + 2 * Y .* (beta -Y) + 2* (C-mean(G)+mean(Y)) * G)/length(G)...
%         - beta* 2*sum(G+beta -Y)/length(G);
end
function [wi] = whittle_index_aoci(delta,C,G,Y)
    
    row = size(delta,1);
    wi = zeros(row,1);
    for ii = 1:row
        wi(ii,1) = 1 / mean(G) * ((delta(ii,1) + mean(G)) * mean(max(delta(ii,1) - Y,0) + G) ...
            - (1 / 2 * mean(G.^2) + 1 / 2 * mean((max(delta(ii,1) - Y,0)).^2) + mean(G) * delta(ii,1) + mean(max(delta(ii,1) - Y,0).* Y) ) ) - C;
    
    end

    
end
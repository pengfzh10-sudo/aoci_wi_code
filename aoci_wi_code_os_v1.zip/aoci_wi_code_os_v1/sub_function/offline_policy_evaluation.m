function average_cost = offline_policy_evaluation(policy_name,num_sample_path, channel_mode,num_G,mu, N,L,pr,C,resolution,total_time)
     
    aoci = zeros(N,ceil(total_time/resolution),num_sample_path);
    aoi = zeros(N,ceil(total_time/resolution),num_sample_path);
    cn = zeros(N,ceil(total_time/resolution),num_sample_path);


%     aoci_temp = zeros(N,ceil(total_time/resolution));
%     aoi_temp = zeros(N,ceil(total_time/resolution));
%     cn_temp = zeros(N,ceil(total_time/resolution));
% 
%     aoci = zeros(N,ceil(total_time/resolution));
%     aoi = zeros(N,ceil(total_time/resolution));
%     cn = zeros(N,ceil(total_time/resolution));

    
    for ii = 1: num_sample_path
        %ii
        [G, Y] = generate_channel_delay(num_G, pr, channel_mode, mu, L);
        % const, nomal, exp, logn

        switch(policy_name)
            case 'aoci_whittle'
                [aoci(:,:,ii), aoi(:,:,ii),cn(:,:,ii)]=aoci_wi_one_round(N,L,pr,C,G,Y,resolution,total_time);
            case 'aoi_whittle'
                [aoci(:,:,ii), aoi(:,:,ii),cn(:,:,ii)]=aoi_wi_one_round(N,L,pr,C,G,Y,resolution,total_time);
            case 'maf_zw'
                [aoci(:,:,ii), aoi(:,:,ii),cn(:,:,ii)]=maxagefirst_zerowait_one_round(N,L,pr,C,G,Y,resolution,total_time);
            case 'macf_zw'
                [aoci(:,:,ii), aoi(:,:,ii),cn(:,:,ii)]=maxaocifirst_zerowait_one_round(N,L,pr,C,G,Y,resolution,total_time);
            otherwise
%              case 'aoci_whittle'
%                 [aoci_temp, aoi_temp,cn_temp]=aoci_wi_one_round(N,L,pr,C,G,Y,resolution,total_time);
%             case 'aoi_whittle'
%                 [aoci_temp, aoi_temp,cn_temp]=aoi_wi_one_round(N,L,pr,C,G,Y,resolution,total_time);
%             case 'maf_zw'
%                 [aoci_temp, aoi_temp,cn_temp]=maxagefirst_zerowait_one_round(N,L,pr,C,G,Y,resolution,total_time);
%             case 'macf_zw'
%                 [aoci_temp, aoi_temp,cn_temp]=maxaocifirst_zerowait_one_round(N,L,pr,C,G,Y,resolution,total_time);
%            otherwise
        end
%         aoci = aoci + aoci_temp / num_sample_path;
%         aoi  = aoi + aoi_temp / num_sample_path;
%         cn =   cn +    ~cn_temp / num_sample_path;
    end


    average_cost = sum(mean(aoci + C*~cn,[2 3]) ) ;
%     average_cost = mean(aoci + C*cn,'all')  ;



end
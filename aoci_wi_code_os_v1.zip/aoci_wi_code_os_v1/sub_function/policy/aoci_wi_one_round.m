function [aoci, aoi, cn]=aoci_wi_one_round(N,L,pr,C,G,Y,resolution,total_time)


    aoci = zeros(N,ceil(total_time/resolution));
    aoi = zeros(N,ceil(total_time/resolution));
    cn = zeros(N,ceil(total_time/resolution));
    wi = zeros(N,ceil(total_time/resolution));
    channel_state = zeros(L,1);
    channel_delay = zeros(L,1);

    
    initial_aoi = rand(N,1);
    aoci(:,1) = initial_aoi ;
    aoi(:,1) = initial_aoi ;
    A = ones(N,1);
    ack = zeros(N,1) ;
    delay = zeros(N,1) ;
    Y_index = ones(L,1);
    cn(:,1) = A;
    for time = 2:ceil(total_time/resolution)   
        for ll = 1:L
            if(channel_state(ll,1) ~= 0)
                if(channel_delay(ll,1) <= 0)
                    A(channel_state(ll,1)) = 1;
                    ack(channel_state(ll,1)) = 1;
                    channel_state(ll,1) = 0;
                else
                    channel_delay(ll,1) = channel_delay(ll,1) - resolution;
                end
            end
        end
        
        for nn = 1:N
            if(ack(nn,1) == 1)
                ack(nn,1) = 0;
                aoi(nn,time) = delay(nn,1);
                if(rand(1,1) < pr)
                    aoci(nn,time) = aoci(nn,time-1) + resolution ;
                else
                    aoci(nn,time) = delay(nn,1);
                end
            else
                aoi(nn,time) = aoi(nn,time-1) + resolution ;
                aoci(nn,time) = aoci(nn,time-1) + resolution ;
            end
        end

        wi(:,time) = whittle_index_aoci( aoci(:,time), C, G(:,1), Y(:,1) );

        
        for ll = 1:L
            if(channel_state(ll,1) == 0)
                [v,n]=max(wi(:,time).*A) ;
                if(v>0)
                    channel_state(ll,1) = n;
                    channel_delay(ll,1) = Y(Y_index(ll),ll);
                    delay(n,1) = Y(Y_index(ll),ll);
                    Y_index(ll) = Y_index(ll) + 1;
                    A(n,1) = 0;
                end
            end
        end
        cn(:,time) = A;

    end
end
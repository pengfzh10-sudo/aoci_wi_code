function [aoci, cn, beta_k, reward_k, time_k,reward_k_frame, time_k_frame]=aoci_online_one_round(N,L,pr,C,G,Y,resolution,total_time,max_frame)
  
    mean_G = mean(G,'all');
    mean_Y = mean(Y,'all');
    Y_avg =6;%4* mean_G;%8;
    aoci = zeros(N,ceil(total_time/resolution));
    cn = zeros(N,ceil(total_time/resolution));
    beta = zeros(N,ceil(total_time/resolution));
    frame_index = ones(N,1);
    channel_state = zeros(L,1);
    channel_delay = zeros(L,1);
    
    G_k = zeros(N,max_frame);
    Z_k = zeros(N,max_frame);
    Y_k = zeros(N,max_frame);
    beta_k = zeros(N,max_frame);
    reward_k = zeros(N,max_frame);
    time_k = zeros(N,max_frame);
    reward_k_frame = zeros(N,max_frame);
    time_k_frame = zeros(N,max_frame);

    beta_max = 30; %1/2*(Y_parameter(2)+Y_parameter(1)^2+2*C)/Y_parameter(1);
    beta_min = 0; %1/6* Y_parameter(1);
    beta(:,1) =[ 7 6.5 6 5.5];%[15 12 10 8];%[ 7 6.5 6 5.5];%max(beta_max*rand(N,1),beta_min);
   
    beta_k(:,1) = beta(:,1);
    initial_aoi = rand(N,1);
    aoci(:,1) = initial_aoi ;
    A = ones(N,1);
    ack = zeros(N,1) ;
    ack_beta_update = zeros(N,1);
    delay = zeros(N,1) ;
    Y_index = ones(1,L);
    cn(:,1) = A;
    cum_cost = zeros(N,1);
   
    for time = 2:ceil(total_time/resolution)  
        if(max(frame_index) == max_frame)
            break;
        end
        for ll = 1:L
            if(channel_state(ll,1) ~= 0)
                if(channel_delay(ll,1) <= 0)
                    index_source = channel_state(ll,1);
                    frame_source = frame_index(index_source);
                    G_k(index_source,frame_source) = G_k(index_source,frame_source) + delay(index_source,1);
                    Y_k(index_source,frame_source) = delay(index_source,1);
                    Z_k(index_source,frame_source) = max(beta_k(index_source,frame_source)- Y_k(index_source,frame_source),0);
                    if(rand(1,1) < pr)
                        channel_delay(ll,1) = Y(Y_index(ll),ll);
                        delay(index_source,1) = Y(Y_index(ll),ll);
                        Y_index(ll) = Y_index(ll) + 1;  
                    else
                        
                        A(index_source) = 1;
                        ack(index_source) = 1;
                        ack_beta_update(index_source) = 1; 
                        channel_state(ll,1) = 0;
                        
                        G_kk = G_k(index_source,frame_source);
                        Y_kk = Y_k(index_source,frame_source);
                        Z_kk = Z_k(index_source,frame_source);
                        reward_k(index_source,frame_source) =1/2*G_kk^2 + 1/2*Z_kk^2 + Y_kk*Z_kk+ (   C -mean_G + mean_Y) *G_kk; %1/2 * (beta_r + Z_k)^2  + omega * C * (Z_k + 1);
                        time_k(index_source,frame_source) = (Z_kk + G_kk) ;
                        reward_kk = reward_k(index_source,frame_source);
                        time_kk = time_k(index_source,frame_source);
                        if(ll == 3)

                        end
                       
                        beta_k(index_source,frame_source+1) = online_learning_update_beta(beta_k(index_source,frame_source),reward_kk,time_kk,frame_source,Y_avg,beta_min,beta_max);
                    end
                    
                else
                    channel_delay(ll,1) = channel_delay(ll,1) - resolution;
                end
            end
        end
        
        for nn = 1:N
            if(ack(nn,1) == 1)
                ack(nn,1) = 0;
                aoci(nn,time) = delay(nn,1);
            else
               
                aoci(nn,time) = aoci(nn,time-1) + resolution ;
            end
        end

       % wi(:,time) = whittle_index_aoci( aoci(:,time), C, G(:,1), Y(:,1) );

        
        for ll = 1:L
            if(channel_state(ll,1) == 0)
                exceed_threshold = max(aoci(:,time)- beta_k(sub2ind(size(beta_k), (1:size(A,1))', frame_index)),0);
                [v,n]=max(exceed_threshold.*A) ;
                %[v,n]=max(wi(:,time).*A) ;
                if(v>0)
                    if(ack_beta_update(n) == 1)
                        frame_index(n) = frame_index(n) + 1;
                        ack_beta_update(n) = 0; 
                    end
                    channel_state(ll,1) = n;
                    
                    channel_delay(ll,1) = Y(Y_index(ll),ll);
                    delay(n,1) = Y(Y_index(ll),ll);
                    Y_index(ll) = Y_index(ll) + 1;
                    A(n,1) = 0;
                    reward_k_frame(n,frame_index(n)) = cum_cost(n);
                    cum_cost(n) = 0;
                    time_k_frame(n,frame_index(n)) = time;
%                     if(frame_index(n) == 1)
%                         time_k_frame(n,frame_index(n)) = time;
%                     else
%                         time_k_frame(n,frame_index(n)) = time - time_k_frame(n,frame_index(n)-1);
%                     end
                end
            end
        end
        cn(:,time) = A;
        cum_cost = cum_cost + aoci(:,time)+C* ~cn(:,time); 
    end
    time_k_frame(:,2:end) = time_k_frame(:,2:end) - time_k_frame(:,1:end-1);
end
function online_policy_evaluation()
%% ----------------------------------------------------------------------
%% ----------------Online Simulation-------------------------------------
%% ----------------------------------------------------------------------

%% Common Parameters Definition
channel = ['exp', 'const', 'nomal', 'logn', 'bursty', 'correlate'];
resolution = 0.05 ;
total_time = 3000 ;
num_sample_path = 1000 ;
num_G = 5000;
rand_seed = 100 ;
rng(rand_seed);
N = 4;
L = 2;
lambda = 1;
pr = 1/4 ;
C = 10;
max_frame = 300;
    
aoci_online = zeros(N,ceil(total_time/resolution));
cn_online = zeros(N,ceil(total_time/resolution));
beta_online = zeros(N,max_frame);
reward_online = zeros(N,max_frame);
time_online = zeros(N,max_frame);
reward_k_frame = zeros(N,max_frame);
time_k_frame = zeros(N,max_frame);
    

for ii = 1: num_sample_path
    ii
    [G, Y] = generate_channel_delay(num_G, pr, 'exp', lambda, L);  
    [o1, o2, o3, o4, o5, o6, o7] = aoci_online_one_round(N,L,pr,C,G,Y,resolution,total_time,max_frame);
    %[aoci_online(:,:,ii),cn_online(:,:,ii), beta_online(:,:,ii),reward_online(:,:,ii), time_online(:,:,ii),reward_k_frame(:,:,ii),time_k_frame(:,:,ii)] = aoci_online_one_round(N,L,pr,C,G,Y,resolution,total_time,max_frame);
    aoci_online     = aoci_online       + o1    /num_sample_path;
    cn_online       = cn_online         + o2    /num_sample_path;
    beta_online     = beta_online       + o3    /num_sample_path;
    reward_online   = reward_online     + o4    /num_sample_path;
    time_online     = time_online       + o5    /num_sample_path;
    reward_k_frame  = reward_k_frame    + o6    /num_sample_path;
    time_k_frame    = time_k_frame      + o7    /num_sample_path;
 
end



%% plot the convergence cruves of learning parameters
figure
hold on, grid on, box on
set(gcf, 'Position', [100, 100, 500, 500]);
pbaspect([1 1 1])
[row, col] = size(beta_online);
frame_num = 200;
for ii = 1:row
    plot(1:frame_num,beta_online(ii,1:frame_num),'linewidth',2,'DisplayName',['\beta_',num2str(ii) ,'^*'])
end

[G, Y] = generate_channel_delay(num_G, pr, 'exp', lambda, L);
beta_aoci = threhold_aoci(C,G(:,1),Y(:,1));
plot(1:frame_num,repmat(beta_aoci,1,frame_num),'k--','linewidth',2,'DisplayName','\beta^*')

legend show;
yticks(0:0.5:10);
xticks(0:50:frame_num);
xlabel('Frame,$k$','Interpreter', 'Latex','FontSize',18)
ylabel('$\beta_n^*$','Interpreter', 'Latex','FontSize',18)
set(gca,'FontSize',18)



%% plot the convergence cruves of average cost



reward_k_frame1 = sum(reward_k_frame(:,1:frame_num));
time_k_frame1 = mean(time_k_frame(:,1:frame_num),1);
rate_online = cumsum(reward_k_frame1)./cumsum(time_k_frame1);



 avg_cost_aoci_wi = offline_policy_evaluation('aoci_whittle',100, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
 avg_cost_aoi_wi = offline_policy_evaluation('aoi_whittle',100, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
 avg_cost_maf_zw = offline_policy_evaluation('maf_zw',100, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);
 avg_cost_macf_zw = offline_policy_evaluation('macf_zw',100, 'exp',num_G,lambda,N,L,pr,C,resolution,total_time);




%% Plot Result
figure
hold on, grid on, box on
set(gcf, 'Position', [100, 100, 500, 500]);
pbaspect([1 1 1])
     xticks(0:50:200);
     yticks(0:5:50);
%     ylim([0 80]);
plot(1:frame_num,rate_online(1:frame_num),'k--',...
    1:frame_num,avg_cost_aoci_wi*ones(1, frame_num),'r',...
    1:frame_num,avg_cost_aoi_wi*ones(1, frame_num),'c',...
    1:frame_num,avg_cost_maf_zw*ones(1, frame_num),'b',...
    1:frame_num,avg_cost_macf_zw*ones(1, frame_num),'g',...
    'linewidth',2)
legend('Online','Offline AoCI', 'Offline AoI', 'MAF-ZW','MACF-ZW','Location','Best')
xlabel('Frame,$k$','Interpreter', 'Latex','FontSize',18)
ylabel('Average Cost','Interpreter', 'Latex','FontSize',18)
set(gca,'FontSize',18)

end